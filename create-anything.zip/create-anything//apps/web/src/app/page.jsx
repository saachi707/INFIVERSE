"use client";

import { Header } from "@/components/Header/Header";
import { Navigation } from "@/components/Navigation/Navigation";
import { ProblemSection } from "@/components/ProblemSection/ProblemSection";
import { SolutionSection } from "@/components/SolutionSection/SolutionSection";
import { ImpactSection } from "@/components/ImpactSection/ImpactSection";
import { InitiativesSection } from "@/components/InitiativesSection/InitiativesSection";
import { DemoSection } from "@/components/DemoSection/DemoSection";
import { ContactSection } from "@/components/ContactSection/ContactSection";
import { Footer } from "@/components/Footer/Footer";
import { scrollToSection } from "@/utils/scrollToSection";

export default function Home() {
  return (
    <div className="bg-gray-50 text-gray-800">
      <Header />
      <Navigation onNavigate={scrollToSection} />
      <ProblemSection />
      <SolutionSection />
      <ImpactSection />
      <InitiativesSection />
      <DemoSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
