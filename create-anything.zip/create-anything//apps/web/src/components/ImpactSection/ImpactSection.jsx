import { useState } from "react";
import { ImpactResults } from "./ImpactResults";

export function ImpactSection() {
  const [showImpact, setShowImpact] = useState(false);

  const calculateSavings = () => {
    setShowImpact(true);
  };

  return (
    <section
      id="impact"
      className="bg-gradient-to-b from-orange-50 to-white py-20 px-6"
    >
      <div className="max-w-6xl mx-auto">
        <h2 className="text-5xl font-black mb-4 text-center text-orange-600">
          📈 Transforming Mumbai: Quantified Impact
        </h2>
        <div className="h-1 w-40 bg-orange-500 mx-auto mb-12"></div>

        <p className="text-lg mb-12 text-center max-w-3xl mx-auto text-gray-700">
          Deploy ECO-FLOW across Mumbai's 660 signals – watch the savings roll
          in.
        </p>

        <div className="mb-12 rounded-2xl overflow-hidden shadow-2xl">
          <img
            src="https://raw.createusercontent.com/2e6af9a6-b183-478e-b328-c82a18ef225d/"
            alt="Before and After Impact"
            className="w-full h-96 object-cover hover:scale-105 transition duration-500"
          />
        </div>

        <div className="text-center mb-8">
          <button
            onClick={calculateSavings}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-4 px-10 rounded-lg mb-8 transition transform hover:scale-105 shadow-lg text-lg"
          >
            💚 Calculate Mumbai-Wide Savings
          </button>
        </div>

        {showImpact && <ImpactResults />}

        <p className="text-lg italic text-gray-700 text-center">
          These figures are based on Mumbai's unique data – scalable to full
          deployment.
        </p>
      </div>
    </section>
  );
}
