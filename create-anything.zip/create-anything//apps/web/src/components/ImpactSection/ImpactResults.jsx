export function ImpactResults() {
  return (
    <div className="bg-white p-10 rounded-2xl border-4 border-green-500 mb-8 shadow-2xl">
      <p className="text-3xl font-black text-green-600 mb-6 text-center">
        💚 Mumbai-Wide: ₹3.5 Cr Saved Annually! CO₂ Down 70%!
      </p>

      <div className="overflow-x-auto mb-8">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gradient-to-r from-green-500 to-emerald-600 text-white">
              <th className="border border-gray-300 p-4 text-left font-bold">
                Metric
              </th>
              <th className="border border-gray-300 p-4 text-left font-bold">
                Before
              </th>
              <th className="border border-gray-300 p-4 text-left font-bold">
                After ECO-FLOW
              </th>
              <th className="border border-gray-300 p-4 text-left font-bold">
                Savings
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="hover:bg-green-50 transition">
              <td className="border border-gray-300 p-4 font-semibold">
                Electricity Cost
              </td>
              <td className="border border-gray-300 p-4">₹5 Cr/Year</td>
              <td className="border border-gray-300 p-4">₹1.5 Cr/Year</td>
              <td className="border border-gray-300 p-4 font-bold text-lg text-green-600">
                ₹3.5 Cr 📉
              </td>
            </tr>
            <tr className="hover:bg-green-50 transition">
              <td className="border border-gray-300 p-4 font-semibold">
                CO₂ Emissions
              </td>
              <td className="border border-gray-300 p-4">5,000 Tons</td>
              <td className="border border-gray-300 p-4">1,500 Tons</td>
              <td className="border border-gray-300 p-4 font-bold text-lg text-green-600">
                -3,500 Tons 🌍
              </td>
            </tr>
            <tr className="hover:bg-green-50 transition">
              <td className="border border-gray-300 p-4 font-semibold">
                Avg Wait Time
              </td>
              <td className="border border-gray-300 p-4">45 Min/Trip</td>
              <td className="border border-gray-300 p-4">34 Min/Trip</td>
              <td className="border border-gray-300 p-4 font-bold text-lg text-green-600">
                -11 Min ⏱️
              </td>
            </tr>
            <tr className="hover:bg-green-50 transition">
              <td className="border border-gray-300 p-4 font-semibold">
                Payback Period
              </td>
              <td className="border border-gray-300 p-4">-</td>
              <td className="border border-gray-300 p-4">-</td>
              <td className="border border-gray-300 p-4 font-bold text-lg text-green-600">
                3 Months ⚡
              </td>
            </tr>
            <tr className="hover:bg-green-50 transition">
              <td className="border border-gray-300 p-4 font-semibold">
                Jobs Created
              </td>
              <td className="border border-gray-300 p-4">-</td>
              <td className="border border-gray-300 p-4">-</td>
              <td className="border border-gray-300 p-4 font-bold text-lg text-green-600">
                500 Local 👥
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-green-100 to-green-50 p-6 rounded-lg text-center">
          <div className="text-5xl font-black text-green-600 mb-2">₹3.5 Cr</div>
          <p className="font-bold text-gray-700">Annual Savings</p>
        </div>
        <div className="bg-gradient-to-br from-blue-100 to-blue-50 p-6 rounded-lg text-center">
          <div className="text-5xl font-black text-blue-600 mb-2">70%</div>
          <p className="font-bold text-gray-700">Energy Reduced</p>
        </div>
        <div className="bg-gradient-to-br from-purple-100 to-purple-50 p-6 rounded-lg text-center">
          <div className="text-5xl font-black text-purple-600 mb-2">25%</div>
          <p className="font-bold text-gray-700">Less Congestion</p>
        </div>
      </div>
    </div>
  );
}
