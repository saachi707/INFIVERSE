export function Navigation({ onNavigate }) {
  return (
    <nav className="bg-white shadow-lg py-4 px-6 sticky top-0 z-50 border-b-4 border-green-500">
      <div className="max-w-6xl mx-auto flex flex-wrap justify-center gap-4">
        <button
          onClick={() => onNavigate("problem")}
          className="px-4 py-2 hover:bg-green-100 text-green-700 font-bold rounded-lg transition hover:scale-105"
        >
          Problem
        </button>
        <button
          onClick={() => onNavigate("solution")}
          className="px-4 py-2 hover:bg-green-100 text-green-700 font-bold rounded-lg transition hover:scale-105"
        >
          Solution
        </button>
        <button
          onClick={() => onNavigate("impact")}
          className="px-4 py-2 hover:bg-green-100 text-green-700 font-bold rounded-lg transition hover:scale-105"
        >
          Impact
        </button>
        <button
          onClick={() => onNavigate("initiatives")}
          className="px-4 py-2 hover:bg-green-100 text-green-700 font-bold rounded-lg transition hover:scale-105"
        >
          Initiatives
        </button>
        <button
          onClick={() => onNavigate("demo")}
          className="px-4 py-2 hover:bg-green-100 text-green-700 font-bold rounded-lg transition hover:scale-105"
        >
          Demo
        </button>
        <button
          onClick={() => onNavigate("contact")}
          className="px-4 py-2 hover:bg-green-100 text-green-700 font-bold rounded-lg transition hover:scale-105"
        >
          Contact
        </button>
      </div>
    </nav>
  );
}
