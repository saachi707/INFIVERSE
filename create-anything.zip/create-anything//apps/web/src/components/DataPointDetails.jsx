"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

export default function DataPointDetails({ title, content }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="bg-white border-l-4 border-green-500 p-6 rounded-lg shadow-md mb-6">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between hover:bg-gray-50 p-2 -m-2 rounded transition"
      >
        <h4 className="text-lg font-bold text-gray-800 text-left">{title}</h4>
        <ChevronDown
          size={24}
          className={`text-green-500 transition-transform ${
            expanded ? "rotate-180" : ""
          }`}
        />
      </button>
      {expanded && (
        <div className="mt-4 pt-4 border-t border-gray-200 text-gray-700 leading-relaxed">
          {content}
        </div>
      )}
    </div>
  );
}
