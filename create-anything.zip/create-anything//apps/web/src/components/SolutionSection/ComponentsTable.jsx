export function ComponentsTable() {
  return (
    <div className="overflow-x-auto mb-12 shadow-lg rounded-xl">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <th className="border border-gray-300 p-4 text-left font-bold">
              Component
            </th>
            <th className="border border-gray-300 p-4 text-left font-bold">
              Benefit
            </th>
            <th className="border border-gray-300 p-4 text-left font-bold">
              Mumbai-Specific
            </th>
          </tr>
        </thead>
        <tbody>
          <tr className="hover:bg-blue-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              Solar Panel (50W)
            </td>
            <td className="border border-gray-300 p-4">₹0 Grid Bill</td>
            <td className="border border-gray-300 p-4">
              Ideal for 5-6 peak hours/day coastal solar irradiance
            </td>
          </tr>
          <tr className="hover:bg-blue-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              Motion Sensor (₹200)
            </td>
            <td className="border border-gray-300 p-4">70% Energy Save</td>
            <td className="border border-gray-300 p-4">
              Handles high humidity without failure
            </td>
          </tr>
          <tr className="hover:bg-blue-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              AI Camera
            </td>
            <td className="border border-gray-300 p-4">25% Less Jams</td>
            <td className="border border-gray-300 p-4">
              Integrates with Mumbai's ATC system
            </td>
          </tr>
          <tr className="hover:bg-blue-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              LED Light
            </td>
            <td className="border border-gray-300 p-4">Low Heat</td>
            <td className="border border-gray-300 p-4">
              Resists Mumbai's 40°C summers
            </td>
          </tr>
          <tr className="hover:bg-blue-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              Total Cost/Junction
            </td>
            <td className="border border-gray-300 p-4 font-bold text-lg text-green-600">
              ₹8,000
            </td>
            <td className="border border-gray-300 p-4">
              Affordable for BMC's ₹100 Cr smart budget
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
