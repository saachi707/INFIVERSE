import DataPointDetails from "@/components/DataPointDetails";
import { descriptions } from "@/data/descriptions";
import { HowItWorksGrid } from "./HowItWorksGrid";
import { ComponentsTable } from "./ComponentsTable";

export function SolutionSection() {
  return (
    <section
      id="solution"
      className="bg-gradient-to-b from-blue-50 to-white py-20 px-6"
    >
      <div className="max-w-6xl mx-auto">
        <h2 className="text-5xl font-black mb-4 text-center text-blue-600">
          ✨ ECO-FLOW AI: The Game-Changing Solution
        </h2>
        <div className="h-1 w-40 bg-blue-500 mx-auto mb-12"></div>

        <p className="text-lg mb-12 text-center max-w-3xl mx-auto text-gray-700">
          ECO-FLOW AI integrates solar power, motion sensors, and AI cameras
          into traffic signals for Mumbai's humid, high-density streets. No more
          wasteful 24/7 glow – lights adapt intelligently.
        </p>

        <div className="mb-12 rounded-2xl overflow-hidden shadow-2xl">
          <img
            src="https://raw.createusercontent.com/db1d896f-4cac-4d6b-b254-370388ec0e34/"
            alt="ECO-FLOW AI Components"
            className="w-full h-96 object-cover hover:scale-105 transition duration-500"
          />
        </div>

        <h3 className="text-3xl font-bold mb-8 text-center">🛠️ How It Works</h3>
        <HowItWorksGrid />

        <ComponentsTable />

        <h3 className="text-3xl font-bold mb-8 text-center">
          🔬 Component Deep Dives
        </h3>
        <div className="space-y-6">
          <DataPointDetails
            title="☀️ 50W Solar Panel: Harvesting Mumbai's Coastal Sunlight"
            content={descriptions.solar}
          />
          <DataPointDetails
            title="📡 ₹200 Motion Sensor: The Humidity-Resistant Eye"
            content={descriptions.sensor}
          />
          <DataPointDetails
            title="🤖 AI Camera: Smart Vehicle Detection & Timing"
            content={descriptions.camera}
          />
          <DataPointDetails
            title="💡 LED Light: Heat-Resistant & Energy-Efficient"
            content={descriptions.led}
          />
          <DataPointDetails
            title="💳 ₹8,000 Total Cost: Affordable for BMC's Budget"
            content={descriptions.cost}
          />
        </div>
      </div>
    </section>
  );
}
