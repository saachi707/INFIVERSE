export function HowItWorksGrid() {
  return (
    <div className="grid md:grid-cols-2 gap-8 mb-12">
      <div className="bg-gradient-to-br from-blue-100 to-blue-50 p-8 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-4">☀️</div>
        <h4 className="text-xl font-bold mb-3 text-blue-700">
          Solar Harvesting
        </h4>
        <p className="text-gray-700">
          Panels capture Mumbai's 5.5 kWh/m²/day sunlight, powering signals
          grid-free.
        </p>
      </div>
      <div className="bg-gradient-to-br from-blue-100 to-blue-50 p-8 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-4">📡</div>
        <h4 className="text-xl font-bold mb-3 text-blue-700">
          Motion Detection
        </h4>
        <p className="text-gray-700">
          Sensors detect vehicles/pedestrians, dimming to 10% when empty.
        </p>
      </div>
      <div className="bg-gradient-to-br from-blue-100 to-blue-50 p-8 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-4">🤖</div>
        <h4 className="text-xl font-bold mb-3 text-blue-700">AI Adaptation</h4>
        <p className="text-gray-700">
          Cameras count traffic, extending green for busy lanes during monsoon
          peaks.
        </p>
      </div>
      <div className="bg-gradient-to-br from-blue-100 to-blue-50 p-8 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-4">🛡️</div>
        <h4 className="text-xl font-bold mb-3 text-blue-700">Safety First</h4>
        <p className="text-gray-700">
          Never fully off – always visible for Mumbai's unpredictable rains.
        </p>
      </div>
    </div>
  );
}
