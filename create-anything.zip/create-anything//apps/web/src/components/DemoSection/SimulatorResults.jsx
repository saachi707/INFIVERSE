export function SimulatorResults({ output }) {
  return (
    <div className="bg-white p-8 rounded-2xl border-4 border-pink-500 text-left shadow-xl">
      <h4 className="text-2xl font-bold mb-6 text-pink-600">
        📊 Simulation Results:
      </h4>
      <div className="bg-gray-900 text-green-400 p-6 rounded-lg font-mono text-lg">
        <pre className="whitespace-pre-wrap">{output}</pre>
      </div>
    </div>
  );
}
