import { useState } from "react";
import { SimulatorResults } from "./SimulatorResults";

export function DemoSection() {
  const [simOutput, setSimOutput] = useState("");

  const simulate = () => {
    setSimOutput(`
      Simulation: Dadar Junction
      
      Empty Road: Light Dims to 10% – Saves 50W
      Peak Hour (5 PM): AI Extends Green – Reduces Wait by 20%
      Monsoon Mode: Auto-Brighten for Visibility
    `);
  };

  return (
    <section
      id="demo"
      className="bg-gradient-to-b from-pink-50 to-white py-20 px-6"
    >
      <div className="max-w-6xl mx-auto">
        <h2 className="text-5xl font-black mb-4 text-center text-pink-600">
          📹 See ECO-FLOW in Action
        </h2>
        <div className="h-1 w-40 bg-pink-500 mx-auto mb-12"></div>

        <div className="mb-12">
          <div className="rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition">
            <img
              src="https://raw.createusercontent.com/996d707d-db0d-4f63-80f8-0df63d986d4e/"
              alt="ECO-FLOW AI Demo Video"
              className="w-full h-96 object-cover hover:scale-105 transition duration-500"
            />
            <div
              className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 hover:bg-opacity-40 transition rounded-2xl"
              style={{ position: "relative", marginTop: "-384px" }}
            >
              <div className="text-white text-6xl opacity-80 hover:opacity-100 transition">
                ▶️
              </div>
            </div>
          </div>
        </div>

        <p className="text-lg mb-12 text-center max-w-3xl mx-auto">
          <strong className="text-pink-600">Before:</strong> Wasted energy on
          empty Andheri roads at night.{" "}
          <strong className="text-green-600">After:</strong> Smart dimming
          during off-peak hours, full brightness during peak traffic.
        </p>

        <h3 className="text-3xl font-bold mb-8 text-center">
          🎮 Interactive Simulator
        </h3>
        <div className="text-center">
          <button
            onClick={simulate}
            className="bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white font-bold py-4 px-10 rounded-lg mb-8 transition transform hover:scale-105 shadow-lg text-lg"
          >
            🚦 Run Mumbai Junction Simulator
          </button>
        </div>

        {simOutput && <SimulatorResults output={simOutput} />}
      </div>
    </section>
  );
}
