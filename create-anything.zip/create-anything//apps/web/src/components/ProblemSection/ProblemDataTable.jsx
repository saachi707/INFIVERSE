export function ProblemDataTable() {
  return (
    <div className="overflow-x-auto mb-12 shadow-lg rounded-xl">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gradient-to-r from-red-500 to-red-600 text-white">
            <th className="border border-gray-300 p-4 text-left font-bold">
              Data Point
            </th>
            <th className="border border-gray-300 p-4 text-left font-bold">
              Value
            </th>
            <th className="border border-gray-300 p-4 text-left font-bold">
              Description
            </th>
          </tr>
        </thead>
        <tbody>
          <tr className="hover:bg-red-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              Number of Traffic Signals
            </td>
            <td className="border border-gray-300 p-4 font-bold text-lg">
              660
            </td>
            <td className="border border-gray-300 p-4">
              Controlling chaos across Mumbai's sprawling urban landscape
            </td>
          </tr>
          <tr className="hover:bg-red-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              Annual Electricity Cost for Signals
            </td>
            <td className="border border-gray-300 p-4 font-bold text-lg">
              ₹5 Crore
            </td>
            <td className="border border-gray-300 p-4">
              Draining municipal budgets with 24/7 power consumption
            </td>
          </tr>
          <tr className="hover:bg-red-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              Annual Congestion Economic Loss
            </td>
            <td className="border border-gray-300 p-4 font-bold text-lg">
              ₹1 Lakh Crore
            </td>
            <td className="border border-gray-300 p-4">
              Lost productivity from idle engines and frustrated commuters
            </td>
          </tr>
          <tr className="hover:bg-red-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              Energy Waste Percentage
            </td>
            <td className="border border-gray-300 p-4 font-bold text-lg">
              70%
            </td>
            <td className="border border-gray-300 p-4">
              Signals glowing bright on empty roads, day and night
            </td>
          </tr>
          <tr className="hover:bg-red-50 transition">
            <td className="border border-gray-300 p-4 font-semibold">
              CO₂ Emissions from Idle Signals
            </td>
            <td className="border border-gray-300 p-4 font-bold text-lg">
              5,000 Tons/Year
            </td>
            <td className="border border-gray-300 p-4">
              Silent killer of Mumbai's air quality and climate goals
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
