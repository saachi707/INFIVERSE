import DataPointDetails from "@/components/DataPointDetails";
import { descriptions } from "@/data/descriptions";
import { ProblemDataTable } from "./ProblemDataTable";

export function ProblemSection() {
  return (
    <section
      id="problem"
      className="bg-gradient-to-b from-red-50 to-white py-20 px-6"
    >
      <div className="max-w-6xl mx-auto">
        <h2 className="text-5xl font-black mb-4 text-center text-red-600">
          🔴 Mumbai's Traffic & Energy Nightmare
        </h2>
        <div className="h-1 w-40 bg-red-500 mx-auto mb-8"></div>

        <p className="text-lg mb-12 text-center max-w-3xl mx-auto text-gray-700">
          Mumbai, the bustling heart of India, faces explosive urban challenges
          with 20 million vehicles daily navigating 660 traffic signals. These
          signals glow relentlessly—wasting energy, draining budgets, and
          choking the city's productivity.
        </p>

        <div className="mb-12 rounded-2xl overflow-hidden shadow-2xl">
          <img
            src="https://raw.createusercontent.com/34d2f27c-18a8-4e82-8716-475b5894a3e2/"
            alt="Mumbai Traffic Problem"
            className="w-full h-96 object-cover hover:scale-105 transition duration-500"
          />
        </div>

        <ProblemDataTable />

        <h3 className="text-3xl font-bold mb-8 text-center text-gray-800">
          Detailed Insights
        </h3>
        <div className="space-y-6">
          <DataPointDetails
            title="📊 660 Traffic Signals: The Infrastructure Backbone"
            content={descriptions.signals}
          />
          <DataPointDetails
            title="⚡ ₹5 Crore Annual Electricity Cost: The Hidden Budget Drain"
            content={descriptions.electricity}
          />
          <DataPointDetails
            title="💰 ₹1 Lakh Crore Congestion Loss: The Economic Hemorrhage"
            content={descriptions.congestion}
          />
          <DataPointDetails
            title="🔥 70% Energy Waste: The Inefficiency Crisis"
            content={descriptions.waste}
          />
          <DataPointDetails
            title="🌍 5,000 Tons CO₂ Emissions: The Climate Impact"
            content={descriptions.emissions}
          />
        </div>
      </div>
    </section>
  );
}
