export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-gray-900 to-black text-white text-center py-8 px-6 border-t-4 border-green-500">
      <p className="font-bold text-lg">
        &copy; 2025 ECO-FLOW AI | Powering Mumbai's Sustainable Future
      </p>
      <p className="text-green-400 mt-2">🌍 Built for a Better Tomorrow</p>
    </footer>
  );
}
