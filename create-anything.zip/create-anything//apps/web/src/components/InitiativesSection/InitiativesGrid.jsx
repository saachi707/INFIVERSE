export function InitiativesGrid() {
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
      <div className="bg-gradient-to-br from-blue-100 to-blue-50 p-6 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-3">🔗</div>
        <h4 className="text-lg font-bold mb-2 text-blue-700">
          ATC Integration
        </h4>
        <p className="text-sm text-gray-700">
          Enhance 253 adaptive signals with solar efficiency
        </p>
      </div>
      <div className="bg-gradient-to-br from-purple-100 to-purple-50 p-6 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-3">📡</div>
        <h4 className="text-lg font-bold mb-2 text-purple-700">ITMS Synergy</h4>
        <p className="text-sm text-gray-700">
          Real-time data from 1,000+ CCTV feeds
        </p>
      </div>
      <div className="bg-gradient-to-br from-yellow-100 to-yellow-50 p-6 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-3">☀️</div>
        <h4 className="text-lg font-bold mb-2 text-yellow-700">Solar Pilots</h4>
        <p className="text-sm text-gray-700">
          Build on Kalyan's success for deployment
        </p>
      </div>
      <div className="bg-gradient-to-br from-pink-100 to-pink-50 p-6 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-3">🅿️</div>
        <h4 className="text-lg font-bold mb-2 text-pink-700">Smart Parking</h4>
        <p className="text-sm text-gray-700">
          15% holistic congestion reduction
        </p>
      </div>
      <div className="bg-gradient-to-br from-teal-100 to-teal-50 p-6 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-3">🌧️</div>
        <h4 className="text-lg font-bold mb-2 text-teal-700">Monsoon Ready</h4>
        <p className="text-sm text-gray-700">
          IP65-rated for 2,500mm annual rain
        </p>
      </div>
      <div className="bg-gradient-to-br from-indigo-100 to-indigo-50 p-6 rounded-xl shadow-lg hover:shadow-2xl transition">
        <div className="text-4xl mb-3">🎯</div>
        <h4 className="text-lg font-bold mb-2 text-indigo-700">Full Support</h4>
        <p className="text-sm text-gray-700">
          End-to-end implementation & support
        </p>
      </div>
    </div>
  );
}
