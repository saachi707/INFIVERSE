import DataPointDetails from "@/components/DataPointDetails";
import { descriptions } from "@/data/descriptions";
import { InitiativesGrid } from "./InitiativesGrid";

export function InitiativesSection() {
  return (
    <section
      id="initiatives"
      className="bg-gradient-to-b from-green-50 to-white py-20 px-6"
    >
      <div className="max-w-6xl mx-auto">
        <h2 className="text-5xl font-black mb-4 text-center text-green-600">
          🌱 Mumbai's Smart City Vision
        </h2>
        <div className="h-1 w-40 bg-green-500 mx-auto mb-12"></div>

        <div className="mb-12 rounded-2xl overflow-hidden shadow-2xl">
          <img
            src="https://raw.createusercontent.com/156decc4-d74b-46e1-9b6a-8f775c98f293/"
            alt="Green Revolution Banner"
            className="w-full h-96 object-cover hover:scale-105 transition duration-500"
          />
        </div>

        <p className="text-lg mb-12 text-center max-w-3xl mx-auto text-gray-700">
          ECO-FLOW aligns perfectly with BMC's initiatives like the Advanced
          Traffic Control (ATC) project covering 253 signals and the Intelligent
          Traffic Management System (ITMS).
        </p>

        <InitiativesGrid />

        <h3 className="text-3xl font-bold mb-8 text-center">
          📋 Initiative Details
        </h3>
        <div className="space-y-6">
          <DataPointDetails
            title="🔗 ATC Integration: 253 Adaptive Signals Enhanced"
            content={descriptions.atc}
          />
          <DataPointDetails
            title="📡 ITMS Synergy: 1,000+ CCTV Feeds Integrated"
            content={descriptions.itms}
          />
          <DataPointDetails
            title="☀️ Kalyan Pilot: Proven Success Blueprint"
            content={descriptions.kalyan}
          />
          <DataPointDetails
            title="🅿️ Smart Parking App: Holistic 15% Congestion Reduction"
            content={descriptions.parking}
          />
          <DataPointDetails
            title="🌧️ Monsoon Resilience: IP65-Rated for 2,500mm Rain"
            content={descriptions.monsoon}
          />
        </div>
      </div>
    </section>
  );
}
