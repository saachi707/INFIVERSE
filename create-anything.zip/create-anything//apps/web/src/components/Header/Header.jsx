export function Header() {
  return (
    <header className="bg-gradient-to-br from-green-600 via-green-500 to-emerald-600 text-white text-center py-20 px-6 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-40 h-40 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-10 w-60 h-60 bg-white rounded-full blur-3xl"></div>
      </div>
      <div className="relative z-10">
        <h1 className="text-6xl font-black mb-6 drop-shadow-lg">
          🌍 ECO-FLOW AI
        </h1>
        <p className="text-2xl mb-3 font-bold drop-shadow-md">
          The World's First Solar-Powered Adaptive Traffic Light
        </p>
        <p className="text-xl font-semibold drop-shadow-md mb-6">
          Revolutionizing Mumbai's Roads
        </p>
        <p className="text-lg drop-shadow-md">
          💚 Saving 70% Energy & 25% Congestion – One Signal at a Time
        </p>
      </div>
    </header>
  );
}
