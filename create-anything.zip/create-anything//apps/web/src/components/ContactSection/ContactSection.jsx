import { useState } from "react";
import { ContactForm } from "./ContactForm";

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    setFormData({ name: "", email: "", message: "" });
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section
      id="contact"
      className="bg-gradient-to-br from-gray-800 to-gray-900 py-20 px-6"
    >
      <div className="max-w-6xl mx-auto">
        <h2 className="text-5xl font-black mb-4 text-center text-white">
          🚀 Get Involved in Mumbai's Green Revolution
        </h2>
        <div className="h-1 w-40 bg-green-500 mx-auto mb-12"></div>

        <ContactForm
          formData={formData}
          submitted={submitted}
          onFormChange={handleFormChange}
          onFormSubmit={handleFormSubmit}
        />

        <div className="text-center text-white bg-gray-800 p-8 rounded-2xl">
          <p className="text-2xl mb-4 font-bold">
            📧 <span className="text-green-400">info@ecoflowai.in</span>
          </p>
          <p className="text-xl font-semibold text-gray-300">
            🌉 Pilot Ready for Bandra-Worli Sea Link Junctions
          </p>
        </div>
      </div>
    </section>
  );
}
