export function ContactForm({
  formData,
  submitted,
  onFormChange,
  onFormSubmit,
}) {
  return (
    <form
      onSubmit={onFormSubmit}
      className="bg-white p-10 rounded-2xl shadow-2xl max-w-2xl mx-auto mb-12"
    >
      <div className="mb-6">
        <label className="block text-lg font-bold mb-3 text-gray-800">
          Name
        </label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={onFormChange}
          required
          className="w-full border-2 border-gray-300 rounded-lg p-4 focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 transition"
        />
      </div>

      <div className="mb-6">
        <label className="block text-lg font-bold mb-3 text-gray-800">
          Email
        </label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={onFormChange}
          required
          className="w-full border-2 border-gray-300 rounded-lg p-4 focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 transition"
        />
      </div>

      <div className="mb-6">
        <label className="block text-lg font-bold mb-3 text-gray-800">
          Message
        </label>
        <textarea
          name="message"
          value={formData.message}
          onChange={onFormChange}
          required
          rows="5"
          className="w-full border-2 border-gray-300 rounded-lg p-4 focus:outline-none focus:border-green-500 focus:ring-2 focus:ring-green-200 transition"
        />
      </div>

      <button
        type="submit"
        className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-4 rounded-lg transition transform hover:scale-105 text-lg shadow-lg"
      >
        ✉️ Send Message
      </button>

      {submitted && (
        <p className="mt-6 text-center text-green-600 font-bold text-lg bg-green-50 p-4 rounded-lg">
          ✅ Thanks! We'll connect for Mumbai pilot.
        </p>
      )}
    </form>
  );
}
